<?php
header("Location: pages/home.php");
exit;
?>
