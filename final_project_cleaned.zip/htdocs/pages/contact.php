<?php
// pages/contact.php
include("../includes/header.php");
include("../includes/nav.php");
?>

<main class="contact_section">
  <h2>Contact Me</h2>
  <p>If you would like to reach out, please send me an email at:</p>
  <p><a id="emailLink" href="#">moc.liamg@eiarzanayar</a></p>
</main>

<?php include("../includes/footer.php"); ?>
<script src="../scripts/email.js"></script>
